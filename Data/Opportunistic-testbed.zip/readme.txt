###################
## rssi_data.mat ##
###################
# All the measurements were carried out using tmote sky nodes with transmitting power P_tx = -1 [dBm] 

% 1) "concorde" collects rssi measurements between 2 tmote sky nodes (A and B).
%    During the measurements A and B preserved the same mutual orientation. 
%
concorde(i,j,k), i=1:360, j=1:4, k=1:23
concorde(i,1,k) = distance between A and B [m]
concorde(i,2,k) = angle between A and B (with respect to a particular two dimensional coordinate system) [rad]
concorde(i,3,k) = rssi_(A->B) [dBm]
concorde(i,4,k) = rssi_(B->A) [dBm]

% 2) "discorde" collects rssi measurements between 2 tmote sky nodes (A and B).
%    During the measurements the mutual orientation of A and B changed. 
%
discorde(i,j,k), i=1:360, j=1:4, k=1:23
discorde(i,1,k) = distance between A and B [m]
discorde(i,2,k) = angle between A and B (with respect to a particular two dimensional coordinate system) [rad]
discorde(i,3,k) = rssi_(A->B) [dBm]
discorde(i,4,k) = rssi_(B->A) [dBm]

% 3) "percorso(n)", (n)=1,...,5, collects the measurements among a mote (User) and 24 nodes (Peers).
%    CHANNEL CHARACTERIZATION : P_rx = P_tx + K - 10*eta*log10(dist/d_0) + psi
%    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    P_rx -> received power
%    P_tx -> transmitted power
%    K -> path loss factor (@ d_0)
%    eta -> path loss coefficient
%    dist -> distance between pairs of nodes
%    d_0 -> reference distance (far field condition)
%    psi -> shadowing, normally distributed with zero mean and std deviation sigma_psi
%    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    We used the aggregate data to define the channel parameters d_0, K, eta, sigma_psi.
%    P_tx = -1 [dBm]
%    d_0 = 0.1 [m]
%    K = -36 [dB]
%    eta = 1.74
%    sigma_psi = 6 [dB]
%
%    We used the following formula to estimate the distance exploiting RSSI samples:
%
%    d_stim(RSSI) =  d_0*10^[(P_tx + K - RSSI)/(10*eta)]*exp(-0.5*{sigma_psi*[log(10)/(10*eta)]}^2)
%
percorso(n)(i,j), i=1:576, j=1:9
percorso(n)(i,1) = Peer id
percorso(n)(i,2:3) = Peer coordinates (x,y) [m]
percorso(n)(i,4) = rssi_(U->P) [dBm]
percorso(n)(i,5) = rssi_(P->U) [dBm]
percorso(n)(i,6) = [rssi_(U->P) + rssi_(P->U)]/2 [dBm]
percorso(n)(i,7) = d_stim(percorso(n)(i,6)) [m]
percorso(n)(i,8:9) = User coordinates (x,y) [m]

